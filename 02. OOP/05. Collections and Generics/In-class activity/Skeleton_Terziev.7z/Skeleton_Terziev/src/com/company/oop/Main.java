package com.company.oop;

public class Main {
    public static void main(String[] args) {

    }
}