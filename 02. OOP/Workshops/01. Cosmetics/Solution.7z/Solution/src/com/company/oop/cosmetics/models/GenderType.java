package com.company.oop.cosmetics.models;

public enum GenderType {
    WOMEN,
    UNISEX,
    MEN
}
