package com.company.oop.cosmetics.commands.enums;

public enum CommandType {
    CREATECATEGORY,
    ADDTOCATEGORY,
    REMOVEFROMCATEGORY,
    SHOWCATEGORY,
    CREATESHAMPOO,
    CREATETOOTHPASTE,
    CREATECREAM,
    ADDTOSHOPPINGCART,
    REMOVEFROMSHOPPINGCART,
    TOTALPRICE;
}
