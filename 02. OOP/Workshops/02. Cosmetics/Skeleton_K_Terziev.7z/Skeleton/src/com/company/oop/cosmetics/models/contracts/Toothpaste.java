package com.company.oop.cosmetics.models.contracts;

import java.util.List;

public interface Toothpaste extends Product{

    List<String> getIngredients();

}
